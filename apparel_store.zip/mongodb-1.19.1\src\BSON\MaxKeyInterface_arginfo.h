/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 6c27815fcc33b0b03365b6b24d4145d8621cf13d */




static const zend_function_entry class_MongoDB_BSON_MaxKeyInterface_methods[] = {
	ZEND_FE_END
};

static zend_class_entry *register_class_MongoDB_BSON_MaxKeyInterface(void)
{
	zend_class_entry ce, *class_entry;

	INIT_NS_CLASS_ENTRY(ce, "MongoDB\\BSON", "MaxKeyInterface", class_MongoDB_BSON_MaxKeyInterface_methods);
	class_entry = zend_register_internal_interface(&ce);

	return class_entry;
}
