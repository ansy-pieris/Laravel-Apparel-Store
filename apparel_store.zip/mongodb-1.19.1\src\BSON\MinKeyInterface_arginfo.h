/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: c9b23e875d9dc9ebb0ed3391d88cb2458ed96407 */




static const zend_function_entry class_MongoDB_BSON_MinKeyInterface_methods[] = {
	ZEND_FE_END
};

static zend_class_entry *register_class_MongoDB_BSON_MinKeyInterface(void)
{
	zend_class_entry ce, *class_entry;

	INIT_NS_CLASS_ENTRY(ce, "MongoDB\\BSON", "MinKeyInterface", class_MongoDB_BSON_MinKeyInterface_methods);
	class_entry = zend_register_internal_interface(&ce);

	return class_entry;
}
