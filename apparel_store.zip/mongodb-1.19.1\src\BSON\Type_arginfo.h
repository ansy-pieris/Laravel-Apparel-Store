/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: ece602b4c841263e650ab50fa949a83ad265db69 */




static const zend_function_entry class_MongoDB_BSON_Type_methods[] = {
	ZEND_FE_END
};

static zend_class_entry *register_class_MongoDB_BSON_Type(void)
{
	zend_class_entry ce, *class_entry;

	INIT_NS_CLASS_ENTRY(ce, "MongoDB\\BSON", "Type", class_MongoDB_BSON_Type_methods);
	class_entry = zend_register_internal_interface(&ce);

	return class_entry;
}
